package com.example.pertemuan_v

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
